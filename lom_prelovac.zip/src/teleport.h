void TeleportPulseStuff(int pulse);
