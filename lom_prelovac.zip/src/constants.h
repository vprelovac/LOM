extern char *dirs[];
extern char *dirs2[];
extern  char *teleport_bits[];
extern  char *room_bits[];
extern  char *exit_bits[];
extern  char *sector_types[];
extern  char *genders[];
extern  char *position_types[];
extern  char *player_bits[] ;
extern  char *player_bits2[];
extern  char *player_bits3[];
extern  char *action_bits[];
extern  char *action_bits2[];
extern  char *action_bits3[];
extern  char *preference_bits[];
extern  char *preference_bits2[];
extern  char *affected_bits[];
extern  char *affected_bits2[];
extern  char *affected_bits3[];
extern  char *connected_types[];
extern  char *where[];
extern  char *equipment_types[];
extern  char *item_types[];
extern  char *wear_bits[];
extern  char *extra_bits[];
extern  char *extra_bits2[];
extern  char *apply_types[];
extern  char *container_bits[];
extern  char *drinks[];
extern  char *drinknames[];
extern  int drink_aff[][3];
extern  char *color_liquid[];
extern  char *fullness[];
extern struct str_app_type str_app[];
extern  struct dex_skill_type dex_app_skill[];
extern  byte backstab_mult[];
extern struct dex_app_type dex_app[];
extern struct con_app_type con_app[];
extern  struct int_app_type int_app[];
extern  struct wis_app_type wis_app[];
extern struct race_app_type race_app[];
extern  char *spell_wear_off_msg[];
extern  char *align_types[];
extern  int rev_dir[];
extern  int movement_loss[];
extern  char *weekdays[];
extern  char *month_name[];
extern  char *rmode[];
extern char *channel_bits[];	/* (not for now) read from file */

extern char *race_abbrevs[]; 	/* in class.c */
extern char *class_abbrevs[];	/* in class.c */
extern char *spells[];		/* in spell_parser.c */
